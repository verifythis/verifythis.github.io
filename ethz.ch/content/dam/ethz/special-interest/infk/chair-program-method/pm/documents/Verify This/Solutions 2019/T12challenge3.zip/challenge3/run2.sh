mcrl22lps a.mcrl2 a.lps
echo "Checking dataracefreedom"
lps2pbes -f dataracefreedom.mcf a.lps a.pbes
pbessolve a.pbes
echo "Checking correct"
lps2pbes -f correct.mcf a.lps a.pbes
pbessolve a.pbes
