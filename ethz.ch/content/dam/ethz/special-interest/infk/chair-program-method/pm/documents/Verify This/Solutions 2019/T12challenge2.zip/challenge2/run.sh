mcrl22lps a.mcrl2 a.lps
lps2pbes -f leftissmaller.mcf a.lps a.leftissmaller.pbes
lps2pbes -f propervalue.mcf a.lps a.propervalue.pbes
lps2pbes -f nosmaller.mcf a.lps a.nosmaller.pbes
echo "Checking leftissmaller"
pbessolve a.leftissmaller.pbes
echo "Checking propervalue"
pbessolve a.propervalue.pbes
echo "Checking nosmaller"
pbessolve a.nosmaller.pbes
