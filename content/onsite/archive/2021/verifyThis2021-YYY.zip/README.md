# Solutions to VerifyThis 2021 challenges by team `YYY'

Team members:
- Jean-Christophe Filliâtre (CNRS)
- Andrei Paskevich (Univ. Paris-Saclay)

Verification system used:
- Why3, version 1.4.0
- available at http://why3.lri.fr/

Solutions are contained in files
- challenge1.mlw
- challenge2.mlw
- challenge3.mlw

Provers used:
- Alt-Ergo 2.3.3
- Z3 4.8.10
- CVC4 1.8
