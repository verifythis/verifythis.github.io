mcrl22lps a.mcrl2 a.lps
lps2pbes -f nonempty.mcf a.lps a.nonempty.pbes
lps2pbes -f begin-to-end.mcf a.lps a.begin-to-end.pbes
lps2pbes -f within-bounds.mcf a.lps a.within-bounds.pbes
lps2pbes -f monotonic.mcf a.lps a.monotonic.pbes
echo "Checking nonempty"
pbessolve a.nonempty.pbes
echo "Checking begin-to-end"
pbessolve a.begin-to-end.pbes
echo "Checking within-bounds"
pbessolve a.within-bounds.pbes
echo "Checking monotonic"
pbessolve a.monotonic.pbes